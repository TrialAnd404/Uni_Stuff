class Pr03Controller < ApplicationController
  layout "pr02"
  def anmeldung

    raise if request.method == 'POST'
  
  end

  def fragebogen

    params['hidden_info'] = 'Versteckte Angabe' if request.method == 'GET'
    raise if request.method == 'POST'
    
  end
end