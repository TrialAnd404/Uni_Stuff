class Pr01Controller < ApplicationController
  def einleitung
  end

  def index
  end

  def kap1
  end

  def kap2
  end

  def tab
  end
end
