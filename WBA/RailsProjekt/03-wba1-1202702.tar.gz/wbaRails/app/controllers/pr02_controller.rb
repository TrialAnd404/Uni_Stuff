class Pr02Controller < ApplicationController
  layout "pr02"
  def einleitung
  end

  def kap1
  end

  def kap2
  end

  def tab
  end
end
