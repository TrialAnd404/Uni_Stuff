require "test_helper"

class Pr03ControllerTest < ActionDispatch::IntegrationTest
  test "should get anmeldung" do
    get pr03_anmeldung_url
    assert_response :success
  end

  test "should get fragebogen" do
    get pr03_fragebogen_url
    assert_response :success
  end
end
