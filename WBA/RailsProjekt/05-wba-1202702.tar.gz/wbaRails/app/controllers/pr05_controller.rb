class Pr05Controller < ApplicationController
	layout "pr05"
  	def tr
  	end
end
