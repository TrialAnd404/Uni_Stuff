var inCalculation = false;
var rad_deg = 1;


Check = function (Eingabe) {
	var nur_das = "0123456789[]()-+*%/.";
	for (var i = 0; i < Eingabe.length; i++)
		if (nur_das.indexOf(Eingabe.charAt(i)) < 0)
			return false;
	return true;
}

Ergebnis = function () {
	console.log("calc end\n");
	inCalculation = false;
	var x = 0;
	var disp = document.Rechner.Display;

	if (Check(disp.value))
		console.log("what the happ is fuckening\n");
	x = eval(disp.value);
	disp.value = x;

	document.Rechner.Display.value = disp.value;
}

Hinzufuegen = function (Zeichen) {
	var disp = document.Rechner.Display;

	if (!inCalculation) {
		console.log("new calc\n");
		disp.value = Zeichen;
		inCalculation = true;
	}
	else
		disp.value = disp.value + Zeichen;

	document.Rechner.Display.value = disp.value;

}

Sonderfunktion = function (Funktion) {
	console.log(Funktion.value);
	var disp = document.Rechner.Display;

	switch (Funktion) {
		case "√x":
			disp.value = Math.sqrt(eval(disp.value));
			break;
		case "x²":
			disp.value = Math.pow(eval(disp.value), 2);
			break;
		case "ln":
			disp.value = Math.log(eval(disp.value));
			break;
		case "sin":
			disp.value = Math.sin(eval(disp.value)) * rad_deg;
			break;
		case "cos":
			disp.value = Math.cos(eval(disp.value)) * rad_deg;
			break;
		case "tan":
			disp.value = Math.tan(eval(disp.value)) * rad_deg;
			break;
		case "cot":
			disp.value = 1 / Math.tan(eval(disp.value)) * rad_deg;
			break;
		case "lg":
			disp.value = Math.log10(eval(disp.value));
			break;
		case "exp":
			disp.value = Math.exp(eval(disp.value));
			break;
		case "asin":
			disp.value = Math.asin(eval(disp.value)) * rad_deg;
			break;
		case "acos":
			disp.value = Math.acos(eval(disp.value)) * rad_deg;
			break;
		case "atan":
			disp.value = Math.atan(eval(disp.value)) * rad_deg;
			break;
		case "10^x":
			disp.value = Math.pow(10(disp.value));
			break;
		default:
			disp.value = 0
			break;
	}
	inCalculation = false;
	document.Rechner.Display.value = disp.value;

}

Umschalten = function (param) {
	console.log("umschalten..\n");
	console.log($(param));

	switch ($(param).attr("id")) {
		case "DegRad":
			console.log("swictching degrad..\n");
			if ($(param).attr("value") == "Rad") {
				$('#DegRad').attr("value", "Deg");
				rad_deg = 1;
				console.log("umgeschaltet auf deg\n");
			} else {
				$('#DegRad').attr("value", "Rad");
				rad_deg = Math.PI / 180;
				console.log("umgeschaltet auf rad\n");
			}
			break;
		case "StdSci":
			console.log("swictching stdsci..\n");
			if ($(param).attr("value") == "Sci") {
				$('#scirechner').slideUp();
				$('#StdSci').attr("value", "Std");
				console.log("umgeschaltet auf std\n");
			} else {
				$('#scirechner').slideDown();
				$('#StdSci').attr("value", "Sci");
				console.log("umgeschaltet auf sci\n");
			}
			break;
		default:
			console.log("unknown button id, skipping..\n");
	}
}

RadDeg = function (RadDeg) {
	console.log("umschalten..\n");

	if (RadDeg == "Rad") {
		$('#DegRad').attr("value", "Deg");
		console.log("umgeschaltet auf deg\n");
	} else {
		$('#DegRad').attr("value", "Rad");
		console.log("umgeschaltet auf rad\n");
	}
}


jQuery(document).ready(() => console.log("turboRechner\n\n"))

$(document).ready(function () {
	//initialisierung
	$('#scirechner').hide();

	$('input[type="button"]').click(function (event) {
		//console.log(event);
		switch ($(this).attr('data-cmd')) {
			case 'result': Ergebnis(); break;
			case 'function': Sonderfunktion(this.value); break;
			case 'switch': Umschalten($(this)); break;
			default: Hinzufuegen(this.value);
		}
	});
});