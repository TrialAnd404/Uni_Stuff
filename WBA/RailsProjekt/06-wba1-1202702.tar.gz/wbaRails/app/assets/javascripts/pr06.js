var chartType = "pie";
var selectedColumn = 1;

append_row = function (parent, ary, element_name) {
	newRow = "<tr>";
	ary.forEach(element => {
		newRow = newRow.concat("<" + element_name + ">");

		newRow = newRow.concat(element);
		newRow = newRow.concat("</" + element_name + ">");
	});
	newRow = newRow.concat("</tr>");
	$(parent).append(newRow);
}

draw_chart = function (index, tableType) {
	var displayData = [];
	titletext = "";

	myTable = $('#pr06table').DataTable();

	var myHeader = myTable.table().header();
	titletext += (myHeader.rows[0].childNodes[index].textContent);
	titletext += " [";
	titletext += (myHeader.rows[1].childNodes[index].textContent);
	titletext += "]";

	myTable.rows({ page: 'current' }).every(function (rowIdx, tableLoop, rowLoop) {
		displayData.push([this.data()[0], Number(this.data()[index])]);
	});

	$('#pr06chart').jqChart({
		title: { text: titletext },
		legend: { title: { text: 'EU Länder' } },
		series: [
			{
				type: tableType,
				data: displayData
			}
		]
	});

}

$(document).ready(function () {


	$.getJSON('/eu-data.json')
		.done(function (data) {
			var i = 0;

			$.each(data, function (key, value) {
				// Ihr Code zum Verarbeiten der EU-Daten …

				if (i == 0) {
					//titel, skippen
				} else if (i == 1) {
					append_row(pr06thead, data['Spaltentitel'], 'th');
				} else if (i == 2) {
					append_row(pr06thead, data['Einheit'], 'th');
				}
				else {
					append_row("#pr06tbody", [key].concat(value), "td");
				}
				i = i + 1;
			});
			var myTable = $('#pr06table').DataTable();
			$('#pr06table')
				.on('page.dt search.dt length.dt', function () {
					draw_chart(selectedColumn, chartType);
				});

			/*
						$('#pr06table').on('click', 'tbody td', function () { // JS-Variante
							alert('Clicked on cell in visible column: ' + myTable.cell(this).index().columnVisible);
						}
						);
			*/

			draw_chart(1, chartType);

			$('#pr06table').on('click', 'thead th', (element) => { // JS-Variante
				selectedColumn = $(element.currentTarget).index();

				if (selectedColumn != 0 && selectedColumn != 3 && selectedColumn != 4)
					draw_chart(selectedColumn, chartType);
			}
			);

			$('#pr06chart').on("click", (evt) => {
				if (chartType == "pie") {
					chartType = "column";
					draw_chart(selectedColumn, chartType);
				}
				else {
					chartType = "pie";
					draw_chart(selectedColumn, chartType);
				}
			});



		})
		.fail(function (d, textStatus, error) {
			alert("getJSON gescheitert, Status: " +
				textStatus + ", Fehler: " + error);
		});
}
);